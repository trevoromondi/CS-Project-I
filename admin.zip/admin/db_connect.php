<?php

$dbserver="localhost";
$dbuser="root";
$password="";
$dbname="cs_project";

$conn=mysqli_connect($dbserver,$dbuser,$password,$dbname);

?>